import './styles.css'
import {useState, useContext} from 'react'
import { ImageContext } from '../../App';

function SearchField() {

  const [searchValue, setSearchValue] = useState("");
  const { fetchData, setSearchImage } = useContext(ImageContext);

  const handleInputChange = (e) => {
    setSearchValue(e.target.value)
  }

  const handleButtonSearch = () => {
    fetchData(`search/photos?page=1&query=${searchValue}&client_id=uCVztwhHCl6R2CaU9OxSedsnbFy0CUr-kc8OxofkWZw`)
    setSearchValue('');
    setSearchImage(searchValue);

  }

  const handleEnterSearch = (e) => {
    if(e.key === 'Enter'){
      fetchData(`search/photos?page=1&query=${searchValue}&client_id=uCVztwhHCl6R2CaU9OxSedsnbFy0CUr-kc8OxofkWZw`)
      setSearchValue(e.target.value);
      setSearchImage(searchValue);
    }
  }

  return (
    <div>
        <input 
            className="search"
            type="search"
            placeholder=" Search Anything..."
            value={searchValue}
            onChange = {handleInputChange}
            onKeyDown={handleEnterSearch}
        />
        <button
            onClick={handleButtonSearch}
            className='button'
        >Search</button>
    </div>
  )
}

export default SearchField