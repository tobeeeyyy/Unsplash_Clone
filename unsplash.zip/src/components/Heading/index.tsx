import SearchField from './SearchField'
import './styles.css'

function Heading({children}){
  return (
    <div className='Header' >
        <div className='H1'>
            Unsplash Clone
        </div>
        {children}
    </div>
  )
}

export default Heading